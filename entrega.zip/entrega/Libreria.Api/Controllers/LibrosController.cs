﻿using Libreria.Services.Dto;
using Libreria.Services.Interfaces.Administracion;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Libreria.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LibrosController : ControllerBase
    {

        private readonly IAdministracionService administracionService;


        public LibrosController(IAdministracionService administracionService)
        {
            this.administracionService = administracionService;
        }

        // GET: api/<LibrosController>
        [HttpGet]
        public IEnumerable<LibroDTO> Get(string autor, int? anio, string titulo)
        {
            return administracionService.ObtenerLibros(autor, anio, titulo);
        }

        // GET api/<LibrosController>/5
        [HttpGet("{id}")]
        public LibroDTO Get(int id)
        {
            return administracionService.ObtenerLibro(id);
        }

        // POST api/<LibrosController>
        [HttpPost]
        public LibroDTO Post([FromBody] LibroDTO entity)
        {
            return administracionService.InsertarLibro(entity);
        }

        // PUT api/<LibrosController>/5
        [HttpPut]
        public LibroDTO Put([FromBody] LibroDTO entity)
        {
            return administracionService.ActualizarLibro(entity);
        }

        // DELETE api/<LibrosController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            administracionService.EliminarLibro(id);
        }
    }
}

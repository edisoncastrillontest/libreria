﻿using AutoMapper;
using Libreria.Core.Model;
using Libreria.Services.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Libreria.Api.Mapping
{    

    public class MappingDTO : Profile
    {
        public MappingDTO()
        {            
            CreateMap<Libro, LibroDTO>();
            CreateMap<LibroDTO, Libro>();

            CreateMap<Editorial, EditorialDTO>();
            CreateMap<EditorialDTO, Editorial>();

            CreateMap<Autor, AutorDTO>();
            CreateMap<AutorDTO, Autor>();
        }
    }
}

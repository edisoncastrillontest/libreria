﻿using Libreria.Services.Dto;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Libreria.Services.Interfaces.Administracion
{
    public interface IAdministracionService
    {
        LibroDTO InsertarLibro(LibroDTO entidad);
        LibroDTO ActualizarLibro(LibroDTO entidad);
        bool EliminarLibro(int id);
        LibroDTO ObtenerLibro(int id);
        List<LibroDTO> ObtenerLibros(string autor, int? anio, string titulo);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Libreria.Services.Dto
{
    public class BaseResponse
    {
        public string MessageError { set; get; }

        private string status = "OK";

        public string Status {
            get
            {
                return status;
            }
            set {
                status = value;
            } 
        }
        
    }
}

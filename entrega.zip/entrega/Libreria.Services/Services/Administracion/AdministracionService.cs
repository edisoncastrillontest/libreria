﻿using AutoMapper;
using Libreria.Core.Model;
using Libreria.Core.Repositories;
using Libreria.Services.Dto;
using Libreria.Services.Interfaces.Administracion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;

namespace Libreria.Services.Services.Administracion
{
    public class AdministracionService : IAdministracionService
    {
        private readonly IMapper _mapper;
        private readonly IRepository<Libro> _libroRepository;
        private readonly IRepository<Editorial> _editorialRepository;
        private readonly IRepository<Autor> _autorRepository;


        public AdministracionService(IMapper mapper, IRepository<Libro> libroRepository, 
            IRepository<Editorial> editorialRepository, IRepository<Autor> autorRepository) { 
            _mapper = mapper;
            _libroRepository = libroRepository;
            _editorialRepository = editorialRepository;
            _autorRepository = autorRepository;
        }

        public LibroDTO InsertarLibro(LibroDTO entidad)
        {
            var editorial = _editorialRepository.FirstOrDefault(c => c.Id == entidad.EditorialId);
            var autor = _autorRepository.FirstOrDefault(c => c.Id == entidad.AutorId);

            if (editorial == null)
            {
                entidad.MessageError = "La editorial no está registrada.";                
            } else if (autor == null)
            {
                entidad.MessageError = "El autor no está registrado.";
            }
            else {
                var cantidadLibros = _libroRepository.Where(c => c.EditorialId == entidad.EditorialId).Count();
                if (editorial.MaximoLibrosRegistrados == -1 || cantidadLibros <= editorial.MaximoLibrosRegistrados)
                {
                    var record = _mapper.Map<Libro>(entidad);
                    _libroRepository.Insert(record);
                    _libroRepository.Save();
                    entidad = _mapper.Map<LibroDTO>(record);
                }
                else
                {
                    entidad.MessageError = "No es posible registrar el libro, se alcanzó el máximo permitido.";
                }
            }

            if (!string.IsNullOrEmpty(entidad.MessageError))
            {
                entidad.Status = "Error";
            }
            
            return entidad;
        }

        public LibroDTO ActualizarLibro(LibroDTO entidad)
        {   
            var record = _mapper.Map<Libro>(entidad);
            _libroRepository.Update(record);
            _libroRepository.Save();
            entidad = _mapper.Map<LibroDTO>(record);
            return entidad;
        }

        
        public bool EliminarLibro(int id)
        {
            var item = _libroRepository.FirstOrDefault(c => c.Id == id);
            if (item != null)
            {
                _libroRepository.Delete(item);
                _libroRepository.Save();
                return true;
            }
            return false;
        }

        public LibroDTO ObtenerLibro(int id)
        {
            return _libroRepository.Where(c => c.Id == id).Select(c => _mapper.Map<LibroDTO>(c)).FirstOrDefault();            
        }

        public List<LibroDTO> ObtenerLibros(string autor,int? anio, string titulo)
        {
            var query = _libroRepository.GetAll();
            if (!string.IsNullOrEmpty(autor))
            {
                query = query.Where(c => c.Autor.NombreCompleto.Contains(autor));
            }
            if (!string.IsNullOrEmpty(titulo))
            {
                query = query.Where(c => c.Titulo.Contains(titulo));
            }
            if (anio.HasValue)
            {
                query = query.Where(c => c.Anio == anio.Value);
            }

            return query.Select(c => _mapper.Map<LibroDTO>(c)).ToList();
        }
    }
}

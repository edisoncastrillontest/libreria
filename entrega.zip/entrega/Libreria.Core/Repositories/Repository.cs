﻿using Libreria.Core.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Linq.Expressions;
using Microsoft.EntityFrameworkCore;
using System.Data.Entity.Infrastructure;



namespace Libreria.Core.Repositories
{
    public class Repository<TEntity> : IRepository<TEntity> where TEntity : class, new()
    {
        protected readonly LibreriaDataContext _context;
        protected readonly DbSet<TEntity> _entities;

        public Repository(LibreriaDataContext context)
        {
            _context = context;
            _entities = _context.Set<TEntity>();
        }

        public IQueryable<TEntity> AsQueryable()
        {
            return _entities.AsQueryable<TEntity>();
        }

        public IEnumerable<TEntity> Find(Expression<Func<TEntity, bool>> expression)
        {   
            return _context.Set<TEntity>().Where(expression);           
        }

        public IEnumerable<TEntity> Where(Expression<Func<TEntity, bool>> expression, params Expression<Func<TEntity, object>>[] includeProperties)
        {            
            IQueryable<TEntity> query = AsQueryable();
            query = PerformInclusions(includeProperties, query);
            return query.Where(expression);            
        }

        public async Task<TEntity> GetById(int id)
        {
            return await _context.Set<TEntity>().FindAsync(id);
        }

        public TEntity FirstOrDefault(Expression<Func<TEntity, bool>> where, params Expression<Func<TEntity, object>>[] includeProperties)
        {
            IQueryable<TEntity> query = _context.Set<TEntity>().AsQueryable().AsNoTracking();
            query = PerformInclusions(includeProperties, query);
            return query.FirstOrDefault(where);
        }

        public TEntity FirstOrDefault(Expression<Func<TEntity, bool>> where)
        {
            IQueryable<TEntity> query = _context.Set<TEntity>().AsQueryable().AsNoTracking();
            return query.FirstOrDefault(where);            
        }


        public IQueryable<TEntity> GetAll()
        {
            return _context.Set<TEntity>();            
        }

        public IQueryable<TEntity> GetAll(params Expression<Func<TEntity, object>>[] includeProperties)
        {
            IQueryable<TEntity> query = _context.Set<TEntity>().AsQueryable();
            query = PerformInclusions(includeProperties, query);
            return query;
        }

        public async Task<TEntity> AddAsync(TEntity entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException($"{nameof(AddAsync)} entity must not be null");
            }

            
            await _context.AddAsync(entity);
            await _context.SaveChangesAsync();

            return entity;
            
        }

        public void Insert(TEntity entity)
        {
            _context.Add(entity);
            var result = _context.SaveChanges();
        }

        public void Update(TEntity entity)
        {
            _entities.Attach(entity);
            _context.Entry(entity).State = EntityState.Modified;
            var result = _context.SaveChanges();
        }



        public int Save()
        {
            int result = 0;
            result = _context.SaveChanges();
            return result;
        }

        public bool AddRange(IEnumerable<TEntity> entities)
        {            
            _context.Set<TEntity>().AddRange(entities);
            return _context.SaveChanges() > 0;            
        }



        public async Task<TEntity> UpdateAsync(TEntity entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException($"{nameof(AddAsync)} entity must not be null");
            }

            
            _context.Update(entity);
            await _context.SaveChangesAsync();

            return entity;
            
        }

        public bool UpdateRange(IEnumerable<TEntity> entities)
        {

            entities.ToList().ForEach(e =>
            {
                _context.Entry(e).State = (Microsoft.EntityFrameworkCore.EntityState)EntityState.Modified;
            });
            return _context.SaveChanges() > 0;

        }

        public bool DeleteRange(IEnumerable<TEntity> entities)
        {

            if (entities != null && entities.Any())
            {
                this._context.Set<TEntity>().RemoveRange(entities);
                _context.SaveChanges();
            }

            return true;

        }


        public async Task<TEntity> Delete(int id)
        {
            var entity = await _context.Set<TEntity>().FindAsync(id);

            if (entity != null)
            {
                this._context.Set<TEntity>().Remove(entity);
                _context.Entry(entity).State = EntityState.Deleted;
                await _context.SaveChangesAsync();
            }

            return entity;            
        }

        public bool DeleteEntity(int id)
        {            
            var entity = _context.Set<TEntity>().Find(id);

            if (entity != null)
            {
                this._context.Set<TEntity>().Remove(entity);
                _context.SaveChanges();
            }

            return true;
            
        }



        private IQueryable<TEntity> PerformInclusions(IEnumerable<Expression<Func<TEntity, object>>> includeProperties,
                                                IQueryable<TEntity> query)
        {
            return includeProperties.Aggregate(query, (current, includeProperty) => current.Include(includeProperty));
        }

        public void Delete(TEntity entity)
        {
            var dbEntityEntry = _context.Entry<TEntity>(entity);
            if (dbEntityEntry.State != EntityState.Detached)
            {
                dbEntityEntry.State = EntityState.Deleted;
            }
            else
            {
                _entities.Attach(entity);
                _entities.Remove(entity);
            }
        }      
        
    }
}

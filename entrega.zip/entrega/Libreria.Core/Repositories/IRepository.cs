﻿using Libreria.Core.Context;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;


namespace Libreria.Core.Repositories
{
    public interface IRepository<TEntity>
    {
        

        IEnumerable<TEntity> Find(Expression<Func<TEntity, bool>> expression);

        IEnumerable<TEntity> Where(Expression<Func<TEntity, bool>> expression, params Expression<Func<TEntity, object>>[] includeProperties);

        TEntity FirstOrDefault(Expression<Func<TEntity, bool>> where, params Expression<Func<TEntity, object>>[] includeProperties);

        TEntity FirstOrDefault(Expression<Func<TEntity, bool>> where);

        Task<TEntity> GetById(int id);

        IQueryable<TEntity> GetAll();

        IQueryable<TEntity> GetAll(params Expression<Func<TEntity, object>>[] includeProperties);

        Task<TEntity> AddAsync(TEntity entity);

        void Insert(TEntity entity);
        void Update(TEntity entity);
        void Delete(TEntity entity);        
        int Save();

        bool AddRange(IEnumerable<TEntity> entities);

        Task<TEntity> UpdateAsync(TEntity entity);

        bool UpdateRange(IEnumerable<TEntity> entities);

        bool DeleteRange(IEnumerable<TEntity> entities);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore.Infrastructure;

namespace Libreria.Core.Model
{
	[Table("libros", Schema = "dbo")]
	public class Libro
    {
		private readonly ILazyLoader _lazyLoader;

		public Libro()
		{
		}

		public Libro(ILazyLoader lazyLoader)
		{
			_lazyLoader = lazyLoader;
		}

		[Key]
		public int Id { get; set; }
		public string Titulo { get; set; }
		public int Anio { get; set; }
		public string Genero { get; set; }
		public int? NumeroPaginas { get; set; }		
		public int EditorialId { get; set; }		
		public int AutorId { get; set; }		

		public Editorial _editorial;
		public Editorial Editorial
		{
			get => _lazyLoader.Load(this, ref _editorial);
			set => _editorial = value;
		}

		private Autor _autor;
		public Autor Autor
		{
			get => _lazyLoader.Load(this, ref _autor);
			set => _autor = value;
		}
	}
}

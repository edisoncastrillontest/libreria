﻿using Libreria.Core.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Libreria.Core.Context
{
    public class LibreriaDataContext: DbContext
    {
        public LibreriaDataContext(DbContextOptions<LibreriaDataContext> dbContextOptions) : base(dbContextOptions) { 
        }

        public DbSet<Autor> Autores { get; set; }
        public DbSet<Editorial> Editoriales { get; set; }
        public DbSet<Libro> Libros { get; set; }
    }
}

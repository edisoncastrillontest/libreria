create database Libreria
go

use Libreria
go

CREATE TABLE [dbo].[Autores](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[NombreCompleto] [varchar](50) NOT NULL,
	[FechaNacimiento] [datetime] NOT NULL,
	[Ciudad] [varchar](50) NULL,
	[Email] [varchar](50) NOT NULL,
 CONSTRAINT [PK_Autores] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO


CREATE TABLE [dbo].[Editoriales](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Nombre] [varchar](50) NOT NULL,
	[Direccion] [varchar](50) NULL,
	[Telefono] [varchar](50) NULL,
	[Email] [varchar](50) NOT NULL,
	[MaximoLibrosRegistrados] [int] NOT NULL,
 CONSTRAINT [PK_Editoriales] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO


CREATE TABLE [dbo].[Libros](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Titulo] [varchar](50) NOT NULL,
	[Anio] [int] NOT NULL,
	[Genero] [varchar](20) NOT NULL,
	[NumeroPaginas] [int] NULL,
	[EditorialId] [int] NOT NULL,
	[AutorId] [int] NOT NULL,
 CONSTRAINT [PK_Libros] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO


ALTER TABLE Libros
ADD CONSTRAINT Libros_Editoriales_FK FOREIGN KEY (EditoriaId) REFERENCES Editoriales(Id);
go

ALTER TABLE Libros
ADD CONSTRAINT Libros_Autores_FK FOREIGN KEY (AutorId) REFERENCES Autores(Id);
go



insert into [dbo].[Autores](NombreCompleto,FechaNacimiento, Ciudad, Email)
values ('Edison Castrillon', CONVERT(datetime, '1981-03-13',102), 'Medellin','yantoe@gmail.com')	
go

insert into [dbo].[Autores](NombreCompleto,FechaNacimiento, Ciudad, Email)
values ('Andres Restrepo', CONVERT(datetime, '1984-02-11',102), 'Envigado','andres@gmail.com')	
go

insert into [dbo].[Autores](NombreCompleto,FechaNacimiento, Ciudad, Email)
values ('Sara Cano', CONVERT(datetime, '1996-11-07',102), 'Envigado','sara@gmail.com')	
go


insert into [dbo].[Editoriales](Nombre, Direccion, Telefono, Email, MaximoLibrosRegistrados)
values('Oveja Negra','Carrera 120 # 34 - 20', '2735010','ovejanegra@gmail.com', 3)

insert into [dbo].[Editoriales](Nombre, Direccion, Telefono, Email, MaximoLibrosRegistrados)
values('Las Casas','Carrera 20 # 6 - 10', '4356789','lascasas@gmail.com', 2)

insert into [dbo].[Editoriales](Nombre, Direccion, Telefono, Email, MaximoLibrosRegistrados)
values('Lobo de Mar','Carrera 70 # 63 - 107', '5656789','lascasas@gmail.com', -1)



insert into [dbo].[Libros](Titulo, Anio, Genero, NumeroPaginas, EditorialId, AutorId)
values('Cuentos de la Biblia',2004,'Fantasia', 100,1, 1)

insert into [dbo].[Libros](Titulo, Anio, Genero, NumeroPaginas, EditorialId, AutorId)
values('Historias del Futbol',2012,'Aventuras', 100,2, 2)


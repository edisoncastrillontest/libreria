import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Constants } from '../config/constants';
import { HttpService } from './http.service';

@Injectable({
  providedIn: 'root'
})
export class LibrosService {

  private urlLibros: string;
  constructor(private constants: Constants,
      private httpService: HttpService) {
    this.urlLibros = 'Libros';
  }
  

  public ObtenerLibros(autor: String, titulo: String, anio?: Number): Observable<any> {
    const filtro="?autor=" + autor + "&titulo=" + titulo + "&anio=" + (anio != null ? anio : ""); 
    return this.httpService.Get(this.constants.getApiUrl() + this.urlLibros + filtro);
  }
}

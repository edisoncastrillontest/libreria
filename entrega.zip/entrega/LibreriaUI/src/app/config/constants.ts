import { Injectable } from '@angular/core'; 

@Injectable({
    providedIn: 'root'
  }) 
export class Constants {
    private API_ENDPOINT: string = 'https://localhost:44342/api/'; 
    
    constructor() { }

    getApiUrl(): string {
        return this.API_ENDPOINT;
    }
}
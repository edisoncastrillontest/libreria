import { Component, OnInit } from '@angular/core';
import { LibrosService } from 'src/app/services/libros-service.service';
import { Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-list-libros',
  templateUrl: './list-libros.component.html',
  styleUrls: ['./list-libros.component.css']
})
export class ListLibrosComponent implements OnInit {

  libros: any[] = [];
  public cols: any[] = [];
  public autor: String = "";  
  public anio?: Number;
  public titulo: String = "";  
  
  constructor(private librosService: LibrosService) {
    
   }

  ngOnInit(): void {    

    this.onBuscar();  

    this.cols = [
      { field: 'titulo', header: 'Titulo' },
      { field: 'anio', header: 'Año' },
      { field: 'genero', header: 'Genero' },
    ];

  }

  
  onBuscar(){
    this.librosService.ObtenerLibros(this.autor,this.titulo,this.anio).subscribe((response) => {     
      console.table(response.body);
      this.libros = response.body;
    }, error => {      
      throw error;
    });
  }

}
